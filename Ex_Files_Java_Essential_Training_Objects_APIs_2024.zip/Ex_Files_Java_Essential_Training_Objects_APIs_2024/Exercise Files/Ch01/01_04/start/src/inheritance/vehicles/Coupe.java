package inheritance.vehicles;

public class Coupe extends Car {

    public Coupe(){
        setDoors(2);
    }
}