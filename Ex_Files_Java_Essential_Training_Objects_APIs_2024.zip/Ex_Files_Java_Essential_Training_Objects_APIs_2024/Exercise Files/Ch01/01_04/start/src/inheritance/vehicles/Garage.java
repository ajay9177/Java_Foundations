package inheritance.vehicles;

public class Garage {

    public static void main(String[] args) {

        
    }
}
