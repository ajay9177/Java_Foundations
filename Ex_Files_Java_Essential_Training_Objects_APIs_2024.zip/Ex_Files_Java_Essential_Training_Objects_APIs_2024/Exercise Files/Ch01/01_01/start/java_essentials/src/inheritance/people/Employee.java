package inheritance.people;

public class Employee {
}
