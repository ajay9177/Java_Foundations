package inheritance.people;

public class InheritanceChecker {

    public static void main(String[] args) {
        //Person person = new Person();
        Employee employee = new Employee();
    }
}
