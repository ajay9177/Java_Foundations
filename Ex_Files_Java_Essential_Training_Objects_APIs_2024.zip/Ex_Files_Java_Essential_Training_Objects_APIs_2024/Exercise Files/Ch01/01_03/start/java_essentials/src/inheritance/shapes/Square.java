package inheritance.shapes;

import inheritance.shapes.Rectangle;

public class Square extends Rectangle {

}
