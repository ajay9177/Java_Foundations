package exceptions;

public class ThrowingExceptions {

    public static double calculatePay(double hours, double payRate){
        return hours * payRate;
    }
}