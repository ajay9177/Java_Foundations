package interfaces.products;

public class Book {

}
