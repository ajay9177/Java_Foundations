package interfaces.products;

public class Library {

    public static void main(String[] args) {


    }
}
