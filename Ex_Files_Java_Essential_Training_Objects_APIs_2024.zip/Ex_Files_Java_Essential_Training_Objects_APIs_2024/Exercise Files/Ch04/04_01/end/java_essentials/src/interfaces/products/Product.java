package interfaces.products;

public interface Product {

    String getName();
    void setName(String name);
}
