package interfaces.products;

public class Library {

    public static void main(String[] args) {

        Product book = new Book();
        book.setName("In the Kitchen with H+ Sport");

        Book book2 = new Book();
    }
}
