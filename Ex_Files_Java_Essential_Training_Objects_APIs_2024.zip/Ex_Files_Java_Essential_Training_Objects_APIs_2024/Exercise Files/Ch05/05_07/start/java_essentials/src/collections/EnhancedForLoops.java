package collections;

import java.util.ArrayList;
import java.util.List;

public class EnhancedForLoops {

    public static void main(String[] args) {
        List fruits = new ArrayList();
        fruits.add("apple");
        fruits.add("lemon");
        fruits.add("banana");
        fruits.add("orange");
    }
}