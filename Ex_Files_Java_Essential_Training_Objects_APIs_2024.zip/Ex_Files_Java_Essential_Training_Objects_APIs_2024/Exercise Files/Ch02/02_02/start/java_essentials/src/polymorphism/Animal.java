package polymorphism;

public class Animal {

    public void makeSound(){
        System.out.println("unknown animal sound");
    }
}

