package abstraction.shapes;

public class ShapeTester {

    public static void main(String[] args){


    }
}

