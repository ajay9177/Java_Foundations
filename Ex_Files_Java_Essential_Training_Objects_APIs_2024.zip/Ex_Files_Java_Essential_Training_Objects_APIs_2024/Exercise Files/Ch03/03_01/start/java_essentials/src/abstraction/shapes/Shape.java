package abstraction.shapes;

public class Shape {

    
}
